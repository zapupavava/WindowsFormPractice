﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        DataBase database = new DataBase();
        private bool isPasswordVisible = false;

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_load(object sender, EventArgs e)
        { 
        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DataBase database = new DataBase();
            var login = textBox1.Text;
            var password = textBox2.Text;
            string queryString = $"insert into register (login_user, password_user) values('{login}','{password}')";
            SqlCommand command = new SqlCommand(queryString, database.getConnection());
            database.OpenConnection();
            if (command.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Аккаунт успешно создан!", "Успех!");
                Form2 frm_login = new Form2();
                this.Hide();
                frm_login.ShowDialog();

            }
            else {
                MessageBox.Show("Аккаунт не создан!");
           
            }
            database.CloseConnection();
        }
        private Boolean checkUser()
        {
            var loginUser = textBox1.Text;        
            var passUser = textBox2.Text;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataTable table = new DataTable();
            string queryString = $"select id_user, login_user, password_user from register where login_user = '{loginUser}'and password_user = '{passUser}'";
            SqlCommand command = new SqlCommand(queryString , database.getConnection());
            adapter.SelectCommand = command;
            adapter.Fill(table);
            if (table.Rows.Count > 0)
            {
                MessageBox.Show("Пользователь уже существует!");
                return true;
            }
            else
            { 
              return false;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            isPasswordVisible = !isPasswordVisible;

            if (isPasswordVisible)
            {
                textBox2.PasswordChar = '\0'; // Отображаем текст
                button2.Text = "Скрыть"; // Изменяем текст на кнопке для понятности
            }
            else
            {
                textBox2.PasswordChar = '*'; // Скрываем текст
                button2.Text = "Показать";

            }
        }
    }
}
